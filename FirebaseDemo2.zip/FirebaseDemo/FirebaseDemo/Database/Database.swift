//
//  Database.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseFirestore

struct dataModel {
    
    let id1: Int!
    let id2: Int!
    let id3: Int!
    let name: String!
    let timeStamp: Double!
    let user_id: String!
    
    init(name:String, id1:Int, id2:Int, id3: Int, timeStamp: Double ,user_id: String) {
        self.user_id = user_id
        self.name = name
        self.id1 = id1
        self.id2 = id2
        self.id3 = id3
        self.timeStamp = timeStamp
    }
    
    init(snapsot: [String: Any]) {
        
        name = snapsot["name"] as? String ?? ""
        id1 = snapsot["id1"] as? Int ?? 0
        id2 = snapsot["id2"] as? Int ?? 0
        id3 = snapsot["id3"] as? Int ?? 0
        timeStamp = snapsot["timeStamp"] as? Double ?? 0
        user_id = snapsot["user_id"] as? String ?? ""
    }
}
