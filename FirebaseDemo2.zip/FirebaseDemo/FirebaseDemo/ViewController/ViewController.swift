//
//  ViewController.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class ViewController: UIViewController {
    let db = Firestore.firestore()
    var ref: DocumentReference? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        db.collection("Bookings").whereField("user_id", isEqualTo: "2")
            .getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    for document in querySnapshot!.documents {
                        print("\(document.documentID) => \(document.data())")
                        let data = dataModel(snapsot: document.data())
                        print(data.id1!)
                        print(data.id2!)
                        print(data.timeStamp!)
                        print(data.user_id!)
                    }
                }
        }
        
    }

    @IBAction func didTapLogin(_ sender: Any) {
        Auth.auth().signIn(withEmail: "yogesh@mailinator.com", password: "123456") { (user, error) in
            
            if user != nil {
                print("user Login")
                
                let VC = self.storyboard!.instantiateViewController(withIdentifier: "AddNotificationVC") as? AddNotificationVC
                self.navigationController?.pushViewController(VC!, animated: true)
            }
        }
    }
}

