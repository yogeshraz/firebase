module DidYouMean
  VERSION = "1.4.0"
end
