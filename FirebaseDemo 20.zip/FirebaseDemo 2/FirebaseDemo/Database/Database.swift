//
//  Database.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseFirestore

class FirestoreDatabase: NSObject {
    
    static let shared = FirestoreDatabase()
    
    func insertData(parameter: [String: Any], errorCloser:@escaping (Error?) -> ()) {
        
        Firestore.firestore().collection("Bookings").addDocument(data: parameter) { err in
            if let err = err {
                print("Error writing document: \(err)")
            } else {
                print("Document successfully written!")
            }
            errorCloser(err)
        }
    }
    
    func updateData(bookingId: String, parameter: [String: Any], errorCloser:@escaping (Error?) -> ()) {
        Firestore.firestore().collection("Bookings").document(bookingId).updateData([
            "timeStamp": Date().timeIntervalSince1970,
        ]) { err in
            if let err = err {
                print("Error updating document: \(err)")
            } else {
                print("Document successfully updated")
            }
            errorCloser(err)
        }
    }
    
    func deleteData(userId: String, errorCloser:@escaping (Error?) -> ()) {
        Firestore.firestore().collection("Bookings").document(userId).delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
    }
    
    func getAllData(userId: String, closer: @escaping ([DatabaseDataModel], Error?) -> ()) {
        Firestore.firestore().collection("Bookings").whereField("user_id", isEqualTo: userId)
            .getDocuments() { (querySnapshot, err) in
                var docArray = [DatabaseDataModel]()
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    for document in querySnapshot!.documents {
                        print("\(document.documentID) => \(document.data())")
                        let data = DatabaseDataModel(snapsot: document.data())
                        docArray.append(data)
                    }
                }
                closer(docArray,err)
            }
    }
    
    func listeneDocumentChange(userId: String, closer: @escaping (DatabaseDataModel, DocumentChangeType, Error?) -> ()) {
        Firestore.firestore().collection("Bookings").whereField("user_id", isEqualTo: userId)
            .addSnapshotListener { querySnapshot, error in
                guard let snapshot = querySnapshot else {
                    print("Error fetching snapshots: \(error!)")
                    return
                }
                snapshot.documentChanges.forEach { diff in
                    if (diff.type == .added) {
                        print("New Added: \(diff.document.data())")
                    }
                    if (diff.type == .modified) {
                        print("Modified: \(diff.document.data())")
                    }
                    if (diff.type == .removed) {
                        print("Removed: \(diff.document.data())")
                    }
                }
            }
    }
}
