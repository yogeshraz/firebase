//
//  ViewController.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore
import CryptoKit

class ViewController: UIViewController {
    let db = Firestore.firestore()
    var ref: DocumentReference? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        db.collection("Bookings").whereField("user_id", isEqualTo: "2")
//            .getDocuments() { (querySnapshot, err) in
//                if let err = err {
//                    print("Error getting documents: \(err)")
//                } else {
//                    for document in querySnapshot!.documents {
//                        print("\(document.documentID) => \(document.data())")
//                        let data = DatabaseDataModel(snapsot: document.data())
//                        print(data.id1!)
//                        print(data.id2!)
//                        print(data.timeStamp!)
//                        print(data.user_id!)
//                    }
//                }
//            }
        
        // SHA-256
        let string = "100"
        let data = Data(string.utf8)
        let digest = SHA256.hash(data: data)
        let hash = digest.compactMap { String(format: "%02x", $0) }.joined()
        print(hash)

        // AES
        let key = SymmetricKey(size: .bits256)
        let message = "Hello Swift1!".data(using: .utf8)!
        let sealedBox = try! AES.GCM.seal(message, using: key)

        let decryptedData = try? AES.GCM.open(sealedBox, using: key)
        print(String(data: decryptedData ?? Data(), encoding: .utf8) ?? "")
        
        
        
        //
//        do {
//          // encrypt
//          let aes = try AES(keyString: "01234567890123456789012345678901")
//          let encryptedData = try aes.encrypt("101")
//            print(encryptedData.)
//
//          // decrypt
//          let decryptedString = try aes.decrypt(encryptedData)
//          print(decryptedString) // The black knight always triumphs!
//
//        } catch {
//          print(error)
//        }
        
        FirestoreDatabase.shared.getAllData(userId: "2") { array, error in
            print(error?.localizedDescription)
            print(array)
        }
        
        FirestoreDatabase.shared.listeneDocumentChange(userId: "2") { array, type, error in
            
        }
        
    }
    
    @IBAction func didTapLogin(_ sender: Any) {
        let VC = self.storyboard!.instantiateViewController(withIdentifier: "AddNotificationVC") as? AddNotificationVC
        self.navigationController?.pushViewController(VC!, animated: true)
//        Auth.auth().signIn(withEmail: "yogesh@mailinator.com", password: "123456") { (user, error) in
//
//            if user != nil {
//                print("user Login")
//
//                let VC = self.storyboard!.instantiateViewController(withIdentifier: "AddNotificationVC") as? AddNotificationVC
//                self.navigationController?.pushViewController(VC!, animated: true)
//            }
//        }
    }
    
    
}


public extension Data {
    init?(hexString: String) {
      let len = hexString.count / 2
      var data = Data(capacity: len)
      var i = hexString.startIndex
      for _ in 0..<len {
        let j = hexString.index(i, offsetBy: 2)
        let bytes = hexString[i..<j]
        if var num = UInt8(bytes, radix: 16) {
          data.append(&num, count: 1)
        } else {
          return nil
        }
        i = j
      }
      self = data
    }
    /// Hexadecimal string representation of `Data` object.
    var hexadecimal: String {
        return map { String(format: "%02x", $0) }
            .joined()
    }
}
