//
//  AddNotificationVC.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseFirestore

class AddNotificationVC: UIViewController {

    //var ref: DatabaseReference!
    let db = Firestore.firestore()
    var ref: DocumentReference? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view
        //self.ref = Database.database().reference()
        
        db.collection("Bookings").whereField("user_id", isEqualTo: "2")
            .addSnapshotListener { querySnapshot, error in
                guard let snapshot = querySnapshot else {
                    print("Error fetching snapshots: \(error!)")
                    return
                }
                snapshot.documentChanges.forEach { diff in
                    if (diff.type == .added) {
                        print("New city: \(diff.document.data())")
                    }
                    if (diff.type == .modified) {
                        print("Modified city: \(diff.document.data())")
                    }
                    if (diff.type == .removed) {
                        print("Removed city: \(diff.document.data())")
                    }
                }
            }
    }
    
    @IBAction func saveData(_ sender: Any) {
        let randomInt = Int.random(in: 0..<1000)
        var parameters: [String: Any] = [:]
        parameters = ["user_id":"2",
                      "id1" : randomInt+1,
                      "id2" : randomInt+2,
                      "id3" :  randomInt+3,
                      "name" :  randomString(length: 10),
                      "timeStamp" :  Date().timeIntervalSince1970]
        saveDataInDB(param: parameters)
        //self.ref.child("Notifications").childByAutoId().setValue(parameters)
        
    }
    
    func saveDataInDB(param: [String: Any]) {
        
        //db.collection("").document("1")
        
        db.collection("Bookings").addDocument(data: param) { error in
            
        }
        
        
//        ref = db.collection("Bookings/1").addDocument(data: param) { err in
//            if let err = err {
//                print("Error adding document: \(err)")
//            } else {
//                print("Document added with ID: \(self.ref!.documentID)")
//            }
//        }
    }
    
    func randomString(length: Int) -> String {
      let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      return String((0..<length).map{ _ in letters.randomElement()! })
    }
    
    @IBAction func deleteData(_ sender: Any) {
        db.collection("Bookings").document("4vs6YvngQz1SRsfuCuBP").delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
        
    }
    
    
    @IBAction func updateData(_ sender: Any) {
        db.collection("Bookings").document("IBIOAkOv6FO7T3li2Dgb").updateData([
            "timeStamp": Date().timeIntervalSince1970,
        ]) { err in
            if let err = err {
                print("Error updating document: \(err)")
            } else {
                print("Document successfully updated")
            }
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
