//
//  Database.swift
//  FirebaseDemo
//
//  Created by Yogesh Raj on 26/07/22.
//

import UIKit
import FirebaseFirestore

class Database: NSObject {
    
    var db = Firestore.firestore()
    
}

/*struct dataModel {
    
    let key: String!
    let id1: Int!
    let id2: Int!
    let id3: Int!
    let name: String!
    let timeStamp: Double!
    
    let itemRef: DatabaseReference!
    
    init(name:String, id1:Int, id2:Int, id3: Int, timeStamp: Double ,key: String) {
        self.key = key
        self.name = name
        self.id1 = id1
        self.id2 = id2
        self.id3 = id3
        self.timeStamp = timeStamp
        self.itemRef = nil
    }
    
    init(snapsot:DataSnapshot) {
        
        key = snapsot.key
        itemRef = snapsot.ref
        
        let snapValue = snapsot.value as! NSDictionary
        
        name = snapValue["name"] as? String ?? ""
        id1 = snapValue["id1"] as? Int ?? 0
        id2 = snapValue["id2"] as? Int ?? 0
        id3 = snapValue["id3"] as? Int ?? 0
        timeStamp = snapValue["timeStamp"] as? Double ?? 0
    }
}*/
