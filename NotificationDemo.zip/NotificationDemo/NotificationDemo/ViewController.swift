//
//  ViewController.swift
//  NotificationDemo
//
//  Created by Yogesh Raj on 10/08/22.
//

import UIKit
import FirebaseMessaging

class ViewController: UIViewController {

    @IBOutlet weak var copyLbl: UILabel!
    var token = ""
    var fcm = ""
    var fcm2 = ""
    let kAppDelegate         = UIApplication.shared.delegate as! AppDelegate
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let pushManager = PushNotificationManager(userID: "1")
        pushManager.registerForPushNotifications()
        
        token = "AAAAE70uDvM:APA91bGHNOal3Q1UVyBnjeyFeNNGDqAX_7ap3FGT78IsFftoYh84Yr72oZeT-tBPDjD5DcsyF8WNFivl2OcXtP3gVJXmgD5E7UipJpwdTIsSqqWgjsTuqQ4pWRW041cQp1v7C7gRlpgB"
        fcm = "cnwewluAxUXmobMHxUznag:APA91bEe8BxHDWP_TIaKZc3zr217KWHcNcIrRFeiqvqfVac5dHrwD9W177c1Kqi_EuFG9IxcQ092_2FN7grsKMuIWNXmV5MyhyHNztlozMRNCJKXhHkDbbwv1M8C8qNfOEb6J5dqxKdc"
        
        fcm2 = "c6yXRrBmjkBduPlr15UU7T:APA91bFY8g4aFtStAh5eEj-ZKZknMiGL71AQbleB_ddmAzk2Nsygqf5eik-E6zf9G4iE5_OlPEpb5-Ekcjb8eXg3TkTXXPM3sF_84l8QCtzY0b4sOtF9PEDYIfEhukexs6ZwvN3d9Q15"
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
    }
    
    @objc func methodOfReceivedNotification(notification: Notification) {
        
        copyLbl.text = notification.object as? String ?? ""
    }
    
    @IBAction func didTapSendPush(_ sender: UIButton!) {
        
        let sender = PushNotificationSender()
        sender.sendPushNotification(to: [fcm2,fcm], title: "Multiple", body: "Notification")
        //UIPasteboard.general.string = copyLbl.text
    }
}

